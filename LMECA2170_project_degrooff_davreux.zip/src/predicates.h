#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

void exactinit();
float orient2d(float *pa, float *pb, float *pc);
float orient2dfast(float *pa, float *pb, float *pc);

